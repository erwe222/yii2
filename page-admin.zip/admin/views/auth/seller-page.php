<?= \admin\widgets\BreadcrumbWidget::widget([
    'navarr'=>[
        ['name'=>'用户管理','href'=>''],
        ['name'=>'商家列表','href'=>''],
    ]
]);?>
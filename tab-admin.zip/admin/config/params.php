<?php
return [
    'adminRoleName' => '超级管理员',     // 超级管理员角色名
    'adminEmail' => '837215079@qq.com',    // 管理员邮箱
    'cacheTime'  => 86400,                  // 用户登录的缓存时间
    'is_authorization'=>false,               // 后台管理是否开启权限控制验证（默认开启）
    'domain_name'=>'后台管理',
];

<?php
    use yii\helpers\Url;
?>

<?= \admin\widgets\LeftMenuWidget::widget();?>
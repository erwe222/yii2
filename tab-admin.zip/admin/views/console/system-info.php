<style>
    th{background-color: #e6e6e6;}
    th{border-bottom:1px solid #ccc !important;}
</style>

<div class="layui-form">
  <table class="layui-table">
    <tbody>
      <tr><th width="200">服务器计算机名</th><td></td></tr>
      
      <tr><th>服务器IP地址</th><td></td></tr>
      
      <tr><th>服务器域名</th><td></td></tr>
      
      <tr><th>服务器端口</th><td></td></tr>
      
      <tr><th>服务器IIS版本</th><td></td></tr>
      
      <tr><th>本文件所在文件夹</th><td></td></tr>
      
      <tr><th>服务器操作系统</th><td></td></tr>
      
      <tr><th>系统所在文件夹</th><td></td></tr>
      
      <tr><th>服务器当前时间</th><td></td></tr>
      
      <tr><th>服务器上次启动到现在已运行</th><td></td></tr>

      <tr><th>CPU 总数</th><td></td></tr>
      
      <tr><th>CPU 类型</th><td></td></tr>
      
      <tr><th>虚拟内存</th><td></td></tr>
      
      <tr><th>当前程序占用内存</th><td></td></tr>
      
      <tr><th>Asp.net所占内存</th><td></td></tr>
      
      <tr><th>当前Session数量</th><td></td></tr>
      
      <tr><th>当前SessionID</th><td></td></tr>
      
      <tr><th>当前系统用户名</th><td></td></tr>
    </tbody>
  </table>
</div>